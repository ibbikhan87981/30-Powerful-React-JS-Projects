import React from "react";
import Dashboard from "./Tours/Dashboard";
function App() {
  return (
    <div>
      <Dashboard />
    </div>
  );
}

export default App;
