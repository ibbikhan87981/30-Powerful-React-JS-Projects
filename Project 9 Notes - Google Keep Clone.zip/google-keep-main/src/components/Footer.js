import React from "react";

function Footer() {
  return (
    <div className="footer">
      <p>&copy; Google Keep 2021</p>
    </div>
  );
}

export default Footer;
