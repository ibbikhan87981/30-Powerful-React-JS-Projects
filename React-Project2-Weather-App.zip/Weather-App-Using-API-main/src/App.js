import "./App.css";
import SearchMain from "./components/searchMain";

function App() {
  return (
    <div className="App">
      <SearchMain />
    </div>
  );
}

export default App;
